from django.apps import AppConfig


class LoyaltyProgramConfig(AppConfig):
    name = 'loyalty_program'
